import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import AmountInput from './components/AmountInput';
import CurrencyPicker from './components/CurrencyPicker';
import ConvertButton from './components/ConvertButton';

export default function App() {
  const [amount, setAmount] = useState('1');
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [toCurrency, setToCurrency] = useState('EUR');
  const [result, setResult] = useState(null);

  const convertCurrency = () => {
    const url = `https://api.exchangerate-api.com/v4/latest/${fromCurrency}`;

    fetch(url)
      .then(response => response.json())
      .then(data => {
        const rate = data.rates[toCurrency];
        const convertedAmount = (amount * rate).toFixed(2);
        setResult(`${amount} ${fromCurrency} = ${convertedAmount} ${toCurrency}`);
      })
      .catch(error => console.error(error));
  };

  const currencyItems = [
    { label: 'USD', value: 'USD' },
    { label: 'EUR', value: 'EUR' },
    { label: 'MGA', value: 'MGA' },
    { label: 'GBP', value: 'GBP' },
    { label: 'JPY', value: 'JPY' },
  ];

  return (
    <KeyboardAwareScrollView contentContainerStyle={styles.container}>
      <View style={styles.converterContainer}>
        <Text style={styles.title}>CONVERTISSEUR DE DEVISES</Text>
      
        <AmountInput amount={amount} setAmount={setAmount} />
        <View style={styles.pickerContainer}>
          <CurrencyPicker
            selectedValue={fromCurrency}
            onValueChange={setFromCurrency}
            items={currencyItems}
          />
          <CurrencyPicker
            selectedValue={toCurrency}
            onValueChange={setToCurrency}
            items={currencyItems}
          />
        </View>
        <ConvertButton onPress={convertCurrency} />
        {result && <Text style={styles.result}>{result}</Text>}
      </View>
    </KeyboardAwareScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center',
  },
  converterContainer: {
    backgroundColor: '#f19d1e',
    margin: 20,
    borderRadius: 10,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 1,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  pickerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  result: {
    marginTop: 20,
    fontSize: 16,
    textAlign: 'center',
  },
});
