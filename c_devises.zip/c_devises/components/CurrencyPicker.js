import React from 'react';
import RNPickerSelect from 'react-native-picker-select';
import { StyleSheet } from 'react-native';

const CurrencyPicker = ({ selectedValue, onValueChange, items }) => {
  return (
    <RNPickerSelect
      onValueChange={onValueChange}
      items={items}
      style={pickerSelectStyles}
      value={selectedValue}
    />
  );
};

const pickerSelectStyles = StyleSheet.create({

  inputAndroid: {
    fontSize: 16,
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderWidth: 0.5,
    borderColor: 'purple',
    borderRadius: 8,
    color: 'black',
    paddingRight: 30,
    marginBottom: 20,
  },
});

export default CurrencyPicker;
